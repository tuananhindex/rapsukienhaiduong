<?php
echo 'haha';
?>